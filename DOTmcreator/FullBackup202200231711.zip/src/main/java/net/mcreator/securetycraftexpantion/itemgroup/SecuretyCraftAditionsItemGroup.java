
package net.mcreator.securetycraftexpantion.itemgroup;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

import net.mcreator.securetycraftexpantion.item.CREATIVETABICONItem;
import net.mcreator.securetycraftexpantion.SecuretycraftExpantionModElements;

@SecuretycraftExpantionModElements.ModElement.Tag
public class SecuretyCraftAditionsItemGroup extends SecuretycraftExpantionModElements.ModElement {
	public SecuretyCraftAditionsItemGroup(SecuretycraftExpantionModElements instance) {
		super(instance, 3);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabsecurety_craft_aditions") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(CREATIVETABICONItem.block);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}

	public static ItemGroup tab;
}
